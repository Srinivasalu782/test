package com.albertsons.irwo.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.albertsons.irwo.dto.VendorList;
import com.albertsons.irwo.dto.VendorListResponse;
import com.albertsons.irwo.entities.Vendor;
import com.albertsons.irwo.repositories.VendorRepository;
import com.albertsons.irwo.service.VendorService;

@Service
public class VendorServiceImpl implements VendorService {

	@Autowired
	private VendorRepository vendorRepository;

	private ModelMapper mapper;

	@Override
	public VendorListResponse getVendorList(int limit, int offset) {

		List<VendorList> vendorList = vendorRepository.findAll().stream().map(items -> mapper.map(Vendor.class, VendorList.class))
				.collect(Collectors.toList());

		VendorListResponse vendorListResponse = VendorListResponse.builder().vendorList(vendorList).build();

		return vendorListResponse;

	}

	@Override
	public Vendor addVendor(Vendor vendor) {		
		return vendorRepository.save(vendor);
	}

}
