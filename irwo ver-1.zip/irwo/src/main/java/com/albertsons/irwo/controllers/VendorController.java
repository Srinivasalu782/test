package com.albertsons.irwo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.albertsons.irwo.dto.VendorList;
import com.albertsons.irwo.dto.VendorListResponse;
import com.albertsons.irwo.entities.Vendor;
import com.albertsons.irwo.service.VendorService;
import com.albertsons.irwo.serviceImpl.VendorServiceImpl;

@RestController
@RequestMapping("/api")
public class VendorController {

	@Autowired
	private VendorServiceImpl vendorServiceImpl;

	@Autowired
	private VendorService vendorService;

	@GetMapping("/vendors")
	public VendorListResponse getVendorList(@RequestParam int limit, @RequestParam int offset) {
		return vendorServiceImpl.getVendorList(limit, offset);
	}

	@PostMapping("/vendors")
	public ResponseEntity<VendorListResponse> addVendor(@RequestBody VendorListResponse vendorListResponse) {

		Vendor vendorRequest = new Vendor();
		List<VendorList> vendorList = vendorListResponse.getVendorList();

		for (VendorList list : vendorList) {
			vendorRequest.setApVendorCode(list.getApVendorCode());
			vendorRequest.setVendorNumber(list.getVendorNumber());
			vendorRequest.setWimSubCode(list.getWimSubCode());
		}

		Vendor vendor = vendorService.addVendor(vendorRequest);
		for (VendorList list : vendorList) {
			list.setApVendorCode(vendor.getApVendorCode());
			list.setVendorNumber(vendor.getVendorNumber());
			list.setWimSubCode(vendor.getWimSubCode());
		}

		vendorListResponse = VendorListResponse.builder().vendorList(vendorList).build();
		return new ResponseEntity<VendorListResponse>(vendorListResponse, HttpStatus.CREATED);
	}

}
