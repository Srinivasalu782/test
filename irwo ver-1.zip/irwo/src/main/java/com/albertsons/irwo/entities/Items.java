package com.albertsons.irwo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Items {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private Integer cicNumber;

	private int upcNumber;

	private String packNumber;

	private int wHSItem;

	private int description;

	private double unitWeight;

	private double iBCost;

	private int quantity;

	private String shipQuantity;

	private double weight;

	private double amount;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getCicNumber() {
		return cicNumber;
	}

	public void setCicNumber(int cicNumber) {
		this.cicNumber = cicNumber;
	}

	public int getUpcNumber() {
		return upcNumber;
	}

	public void setUpcNumber(int upcNumber) {
		this.upcNumber = upcNumber;
	}

	public String getPackNumber() {
		return packNumber;
	}

	public void setPackNumber(String packNumber) {
		this.packNumber = packNumber;
	}

	public int getwHSItem() {
		return wHSItem;
	}

	public void setwHSItem(int wHSItem) {
		this.wHSItem = wHSItem;
	}

	public int getDescription() {
		return description;
	}

	public void setDescription(int description) {
		this.description = description;
	}

	public double getUnitWeight() {
		return unitWeight;
	}

	public void setUnitWeight(double unitWeight) {
		this.unitWeight = unitWeight;
	}

	public double getiBCost() {
		return iBCost;
	}

	public void setiBCost(double iBCost) {
		this.iBCost = iBCost;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getShipQuantity() {
		return shipQuantity;
	}

	public void setShipQuantity(String shipQuantity) {
		this.shipQuantity = shipQuantity;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
