package com.albertsons.irwo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.albertsons.irwo.entities.Items;
import com.albertsons.irwo.exceptions.NoDataFoundException;
import com.albertsons.irwo.exceptions.ResourceNotFoundException;
import com.albertsons.irwo.repositories.ItemsRepository;
import com.albertsons.irwo.service.ItemsService;

@Service
public class ItemsServiceImpl implements ItemsService {

	@Autowired
	private ItemsRepository itemsRepository;

	@Override
	public Items saveItems(Items items) {
		return itemsRepository.save(items);
	}

	@Override
	public List<Items> getAllItems() {
		List<Items> itemList = itemsRepository.findAll();
		if (itemList.isEmpty()) {
			throw new NoDataFoundException("No Items ");
		}
		return itemList;
	}

	@Override
	public Items getItem(int id) {
		return itemsRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + id));
	}

}
