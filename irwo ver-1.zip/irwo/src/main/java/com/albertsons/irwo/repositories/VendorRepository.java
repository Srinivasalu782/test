package com.albertsons.irwo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.albertsons.irwo.dto.VendorListResponse;
import com.albertsons.irwo.entities.Vendor;

@Repository
public interface VendorRepository extends JpaRepository<Vendor, Integer> {

	VendorListResponse save(VendorListResponse vendorListResponse);

}
