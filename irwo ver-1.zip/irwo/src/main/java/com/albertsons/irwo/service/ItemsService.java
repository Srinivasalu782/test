
package com.albertsons.irwo.service;

import java.util.List;

import com.albertsons.irwo.entities.Items;

public interface ItemsService {

	public Items saveItems(Items items);

	public List<Items> getAllItems();

	public Items getItem(int id);

}
