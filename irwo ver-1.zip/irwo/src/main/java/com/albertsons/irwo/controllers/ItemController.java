package com.albertsons.irwo.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.albertsons.irwo.dto.ItemsDto;
import com.albertsons.irwo.entities.Items;
import com.albertsons.irwo.service.ItemsService;

@RestController
@RequestMapping("/api")
public class ItemController {

	@Autowired
	private ItemsService itemsService;

	@Autowired
	private ModelMapper mapper;

	@PostMapping("/items/saveitems")
	public ResponseEntity<ItemsDto> saveItems(@Valid @RequestBody ItemsDto itemsDto) {
		// convert DTO to entity
		Items itemsRequest = mapper.map(itemsDto, Items.class);

		Items items = itemsService.saveItems(itemsRequest);

		// convert entity to DTO
		ItemsDto itemsResponse = mapper.map(items, ItemsDto.class);
		return new ResponseEntity<ItemsDto>(itemsResponse, HttpStatus.CREATED);
	}

	@GetMapping("/items/getallitems")
	public List<ItemsDto> getAllItems() {
		return itemsService.getAllItems().stream().map(items -> mapper.map(items, ItemsDto.class))
				.collect(Collectors.toList());

	}

	@GetMapping("/items/getitem/{id}")
	public ResponseEntity<ItemsDto> getItem(@PathVariable int id) {

		Items item = itemsService.getItem(id);

		// convert entity to DTO
		ItemsDto itemsResponse = mapper.map(item, ItemsDto.class);

		return ResponseEntity.ok().body(itemsResponse);

	}
}
