
package com.albertsons.irwo.service;

import com.albertsons.irwo.dto.VendorListResponse;
import com.albertsons.irwo.entities.Vendor;

public interface VendorService {

	public VendorListResponse getVendorList(int limit, int offset);
	
	public Vendor addVendor(Vendor vendor);
	
	//save
	//delete

}
